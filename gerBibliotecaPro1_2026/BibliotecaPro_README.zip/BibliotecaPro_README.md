# 📚 BibliotecaPro — Sistema de Gerenciamento de Biblioteca

**FATEC SP · Campus Zona Leste · DSM · Desenvolvimento de Web 3**  
**Professora:** Luciana Akemi | **Aluno:** Adriano Rodrigues de Araujo

---

## 🗂️ Estrutura de Arquivos no Workspace

| Arquivo | Destino no VSCode | Conteúdo |
|---|---|---|
| `BibliotecaPro_schema.sql` | `backend/src/database/schema.sql` | Schema PostgreSQL/Neon + dados de exemplo |
| `BibliotecaPro_backend_server.js` | `backend/server.js` | Express + Swagger + Menu Console (B) |
| `BibliotecaPro_controller.js` | `backend/src/controllers/BibliotecaController.js` | POO: classes Livro, Usuario, Biblioteca |
| `BibliotecaPro_routes_api.js` | `backend/src/routes/api.js` | Rotas REST completas |
| `BibliotecaPro_swagger.json` | `backend/swagger.json` | Documentação OpenAPI 3.0 |
| `BibliotecaPro_frontend_App.jsx` | `frontend/src/App.jsx` + `main.jsx` + `services/api.js` | Layout sidebar + roteamento React |
| `BibliotecaPro_frontend_components.jsx` | `frontend/src/components/` | Dashboard, Livros, Usuarios, Emprestimos, Relatorio (jsPDF) |

---

## 🏗️ Estrutura de Pastas no VSCode

```
biblioteca-pro/
├── backend/
│   ├── src/
│   │   ├── controllers/
│   │   │   └── BibliotecaController.js   ← POO (classes Livro, Usuario, Biblioteca)
│   │   ├── routes/
│   │   │   └── api.js                    ← Rotas REST
│   │   └── database/
│   │       ├── connection.js             ← Pool PostgreSQL/Neon
│   │       └── schema.sql                ← Tabelas + dados exemplo
│   ├── swagger.json                      ← Swagger OpenAPI 3.0
│   ├── .env                              ← Variáveis de ambiente
│   ├── package.json
│   └── server.js                         ← Servidor + Menu Console
├── frontend/
│   ├── public/
│   │   └── index.html                    ← Bootstrap 5.3 + Bootstrap Icons
│   ├── src/
│   │   ├── components/
│   │   │   ├── Dashboard.jsx
│   │   │   ├── Livros.jsx
│   │   │   ├── Usuarios.jsx
│   │   │   ├── Emprestimos.jsx
│   │   │   └── Relatorio.jsx             ← Relatório com jsPDF
│   │   ├── services/
│   │   │   └── api.js                    ← axios interceptor
│   │   ├── App.jsx                       ← Sidebar responsiva + roteamento
│   │   └── main.jsx
│   └── package.json
└── mobile/                               ← React Native (Expo)
    ├── src/screens/
    │   ├── HomeScreen.js
    │   ├── LivrosScreen.js
    │   ├── EmprestimosScreen.js
    │   └── RelatorioScreen.js
    ├── App.js
    └── package.json
```

---

## ⚙️ Configuração Rápida

### 1. Banco de Dados – Neon PostgreSQL

1. Acesse [neon.tech](https://neon.tech) e crie um projeto
2. Copie a connection string: `postgresql://user:pass@host.neon.tech/db?sslmode=require`
3. No Neon SQL Editor, execute o arquivo `BibliotecaPro_schema.sql`

### 2. Backend

```bash
cd backend
npm install
```

Crie o arquivo `backend/.env`:
```env
PORT=3001
NODE_ENV=development
DATABASE_URL=postgresql://USUARIO:SENHA@host.neon.tech/biblioteca_db?sslmode=require
FRONTEND_URL=http://localhost:5173
```

Arquivo `backend/src/database/connection.js`:
```js
require('dotenv').config();
const { Pool } = require('pg');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false },
  max: 10,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 5000,
});

pool.connect((err, client, release) => {
  if (err) { console.error('❌ Erro PostgreSQL:', err.message); return; }
  console.log('✅ PostgreSQL (Neon) conectado!');
  release();
});

const query     = (text, params) => pool.query(text, params);
const getClient = () => pool.connect();

module.exports = { pool, query, getClient };
```

```bash
npm run dev          # inicia com nodemon
```

→ API:     http://localhost:3001/api  
→ Swagger: http://localhost:3001/api-docs

### 3. Frontend React

```bash
cd frontend
npm install
npm run dev
```

→ App: http://localhost:5173

`frontend/package.json`:
```json
{
  "name": "biblioteca-frontend",
  "version": "1.0.0",
  "type": "module",
  "scripts": { "dev": "vite", "build": "vite build", "preview": "vite preview" },
  "dependencies": {
    "axios": "^1.7.2",
    "jspdf": "^2.5.1",
    "jspdf-autotable": "^3.8.2",
    "react": "^18.3.1",
    "react-dom": "^18.3.1",
    "react-router-dom": "^6.23.1"
  },
  "devDependencies": {
    "@vitejs/plugin-react": "^4.3.1",
    "vite": "^5.3.1"
  }
}
```

`backend/package.json`:
```json
{
  "name": "biblioteca-backend",
  "version": "1.0.0",
  "main": "server.js",
  "scripts": { "start": "node server.js", "dev": "nodemon server.js" },
  "dependencies": {
    "cors": "^2.8.5",
    "dotenv": "^16.4.5",
    "express": "^4.19.2",
    "pg": "^8.11.5",
    "swagger-ui-express": "^5.0.1"
  },
  "devDependencies": { "nodemon": "^3.1.0" }
}
```

### 4. Mobile React Native (Expo)

```bash
cd mobile
npx expo install
# Edite o IP em cada Screen: const API = 'http://SEU_IP_LOCAL:3001/api';
npx expo start
```

---

## ✅ Requisitos Atendidos

### (A) Sistema de Gerenciamento com POO + Swagger + jsPDF

| Requisito | Implementação |
|---|---|
| **3 classes POO** | `Livro`, `Usuario`, `Biblioteca` em `BibliotecaController.js` |
| **Métodos por funcionalidade** | `cadastrarLivro()`, `registrarEmprestimo()`, `registrarDevolucao()`, `relatorioStatus()` etc. |
| **Swagger** | OpenAPI 3.0 em `swagger.json` → UI em `/api-docs` |
| **Cadastro de livros** | `POST /api/livros` com CRUD completo |
| **Registro de empréstimos** | `POST /api/emprestimos` com validação de disponibilidade |
| **Registro de devoluções** | `PUT /api/emprestimos/:id/devolver` com cálculo de atraso |
| **Relatório com jsPDF** | Componente `Relatorio.jsx` → botão "Exportar PDF" gera relatório colorido A4 landscape |
| **Comprovante de devolução** | Botão PDF na tabela de status gera comprovante A5 individual |

### (B) Menu Console Interativo

| Opção | Funcionalidade |
|---|---|
| 1 | Cadastrar Livro |
| 2 | Cadastrar Usuário |
| 3 | Registrar Empréstimo (**bloqueia** se livro já emprestado) |
| 4 | Registrar Devolução (indica atraso em dias) |
| 5 | Listar Livros (🟢 / 🔴 por status) |
| 6 | Listar Usuários |
| 7 | Relatório de Status em tabela ASCII |
| 8 | Estatísticas gerais |
| 9 | **Sair** → exibe status final de **todos** os livros antes de encerrar |

---

## 🔒 Regra de Negócio Central

> Um livro com status **Emprestado** **não pode** ser emprestado novamente.  
> Tanto no backend (`podeEmprestar()` → HTTP 409 Conflict) quanto no console (mensagem de erro clara) e no frontend (apenas livros `Disponível` aparecem no select).

---

## 🌐 Endpoints da API

| Método | Rota | Descrição |
|---|---|---|
| GET | `/api/dashboard` | Estatísticas gerais |
| GET | `/api/livros` | Lista livros (filtros: busca, status, genero) |
| POST | `/api/livros` | Cadastra livro |
| PUT | `/api/livros/:id` | Atualiza livro |
| DELETE | `/api/livros/:id` | Remove (somente Disponível) |
| GET | `/api/usuarios` | Lista usuários |
| POST | `/api/usuarios` | Cadastra usuário |
| PUT | `/api/usuarios/:id` | Atualiza usuário |
| DELETE | `/api/usuarios/:id` | Remove usuário |
| GET | `/api/emprestimos` | Lista empréstimos |
| POST | `/api/emprestimos` | Registra empréstimo |
| PUT | `/api/emprestimos/:id/devolver` | Registra devolução |
| GET | `/api/relatorio/status` | Relatório completo de todos os livros |
| GET | `/api/relatorio/emprestados` | Apenas livros emprestados agora |

---

## 📱 Funcionalidades do Frontend

- **Dashboard** responsivo com 7 cards de estatísticas + tabela ao vivo dos emprestados
- **Livros** — CRUD completo com busca, filtro por status e gênero, modal de cadastro/edição
- **Usuários** — CRUD com avatares coloridos por nome
- **Empréstimos** — registro e devolução, filtros Todos/Ativos/Devolvidos, indicador de atraso
- **Relatório** — gráfico de disponibilidade, filtros, exportação PDF A4 paisagem (jsPDF + autoTable)
- **Sidebar** colapsável, responsiva para mobile, navegação por rotas React Router
- **Modo responsivo** — funciona em desktop, tablet e celular

---

*BibliotecaPro © 2025 – FATEC SP Zona Leste – DSM – WEB3*
